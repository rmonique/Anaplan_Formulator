//document.getElementsByClassName('formulaEditorText').addEventListener("click", chnageName);


//function chnageName() {
var  formula = document.getElementsByClassName('formulaEditorText');
if ( formula.length > 0) {
    var formulaToEdit =  formula[0].value;
    var newFormula = formulaToEdit.replace(/IF /g, 'IF \n\n').replace(/ THEN /g, '\n\nTHEN \n\n').replace(/ ELSE /g, '\n\nELSE \n\n')
    document.getElementsByClassName('formulaEditorText')[0].value = newFormula;
    }
//}